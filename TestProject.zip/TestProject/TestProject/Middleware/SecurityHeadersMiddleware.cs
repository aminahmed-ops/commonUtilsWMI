﻿namespace TestProject.Middleware
{
    public class SecurityHeadersMiddleware
    {
        private readonly RequestDelegate _next;

        public SecurityHeadersMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public Task Invoke(HttpContext httpContext)
        {
            //// X-Frame-Options
            //if (!httpContext.Response.Headers.ContainsKey("X-Frame-Options"))
            //{
            //    httpContext.Response.Headers.Add("X-Frame-Options", "ALLOW");
            //}

            //// X-Xss-Protection
            //if (!httpContext.Response.Headers.ContainsKey("X-XSS-Protection"))
            //{
            //    httpContext.Response.Headers.Add("X-XSS-Protection", "1; mode=block");
            //}

            //// X-Content-Type-Options
            //if (!httpContext.Response.Headers.ContainsKey("X-Content-Type-Options"))
            //{
            //    httpContext.Response.Headers.Add("X-Content-Type-Options", "nosniff");
            //}

            //// Referrer-Policy
            //if (!httpContext.Response.Headers.ContainsKey("Referrer-Policy"))
            //{
            //    httpContext.Response.Headers.Add("Referrer-Policy", "no-referrer");
            //}

            //// X-Permitted-Cross-Domain-Policies
            //if (!httpContext.Response.Headers.ContainsKey("X-Permitted-Cross-Domain-Policies"))
            //{
            //    httpContext.Response.Headers.Add("X-Permitted-Cross-Domain-Policies", "none");
            //}

            //// Permissions-Policy
            //if (!httpContext.Response.Headers.ContainsKey("Permissions-Policy"))
            //{
            //    httpContext.Response.Headers.Add("Permissions-Policy", "accelerometer 'none'; camera 'none'; geolocation 'none'; gyroscope 'none'; magnetometer 'none'; microphone 'none'; payment 'none'; usb 'none'");
            //}

            //// Content-Security-Policy
            //if (!httpContext.Response.Headers.ContainsKey("Content-Security-Policy"))
            //{
            //    httpContext.Response.Headers.Add("Content-Security-Policy", "form-action 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval' https://www.google.com https://code.jquery.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://fonts.gstatic.com https://cdn.jsdelivr.net");
            //}

            return _next.Invoke(httpContext);
        }
    }
}
