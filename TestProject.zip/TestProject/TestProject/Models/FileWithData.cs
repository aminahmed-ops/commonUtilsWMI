﻿namespace TestProject.Models
{
    public class FileWithData
    {
        public IFormFile File { get; set; }
        public string FirstName{ get; set; }
    }
}
