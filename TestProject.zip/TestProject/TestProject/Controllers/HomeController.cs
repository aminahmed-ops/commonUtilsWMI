﻿using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using TestProject.Models;
using TestProject.Utilities;
//using static System.Net.Mime.MediaTypeNames;

namespace TestProject.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            try
            {
                var dateSTR = string.Empty;
                DateTime.Parse(dateSTR);

                _logger.LogInformation($"this is a custom log");

                return View();
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex,ex.Message);
                throw ex;
            }
           
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [HttpPost]
        public ActionResult UploadFiles(FileWithData fileWithData)
        {

            var image = Image.FromStream(fileWithData.File.OpenReadStream());
            var resized = new Bitmap(image, new Size(256, 256));
            using var imageStream = new MemoryStream();
            resized.Save(imageStream, ImageFormat.Jpeg);
            var imageBytes = imageStream.ToArray();
            string base64 = Convert.ToBase64String(imageBytes);

            return Json(new {imagestring=base64 });
        }
    }
}