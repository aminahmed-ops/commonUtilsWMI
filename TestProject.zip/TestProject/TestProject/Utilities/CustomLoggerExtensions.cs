﻿using Microsoft.Extensions.Logging;

namespace TestProject.Utilities
{
    public static class CustomLoggerExtensions
    {
        public static ILoggingBuilder AddCustomLogger(this ILoggingBuilder builder, Action<CustomLoggerOptions> configure)
        {
            builder.Services.AddSingleton<ILoggerProvider, CustomLoggerProvider>();
            builder.Services.Configure(configure);
            return builder;
        }    
    }
}
