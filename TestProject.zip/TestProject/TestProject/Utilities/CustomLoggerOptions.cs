﻿namespace TestProject.Utilities
{
    public class CustomLoggerOptions
    {
        public DBOptions DBOptions { get; set; }
        public FileOptions FileOptions { get; set; }
    }
    public class DBOptions
    {
        public string ConnectionString { get; init; }

        public string[] EnabledLogLevels { get; init; }

        public string SPName { get; init; }

        public bool IsDBLogEnabled { get; set; }

        public DBOptions()
        {
        }
    }
    public class FileOptions
    {
        public string LogFilePath { get; set; }
        public string ErrorLogFilePath { get; set; }
    }

}
