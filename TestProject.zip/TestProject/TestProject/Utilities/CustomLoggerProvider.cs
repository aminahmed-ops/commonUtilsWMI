﻿using Microsoft.Extensions.Options;

namespace TestProject.Utilities
{
    public class CustomLoggerProvider:ILoggerProvider
    {
        public readonly CustomLoggerOptions Options;

        public CustomLoggerProvider(IOptions<CustomLoggerOptions> _options)
        {
            Options = _options.Value; // Stores all the options.
        }

        /// <summary>
        /// Creates a new instance of the db logger.
        /// </summary>
        /// <param name="categoryName"></param>
        /// <returns></returns>
        public ILogger CreateLogger(string categoryName)
        {
            return new CustomLogger(this);
        }

        public void Dispose()
        {
        }
    }
}
