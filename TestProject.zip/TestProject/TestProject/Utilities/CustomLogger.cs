﻿using Dapper;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Xml;

namespace TestProject.Utilities
{
    public class CustomLogger : ILogger
    {

        private readonly CustomLoggerProvider _dbLoggerProvider;

        public CustomLogger(CustomLoggerProvider dbLoggerProvider)
        {
            _dbLoggerProvider = dbLoggerProvider;
        }
        public IDisposable BeginScope<TState>(TState state)
        {
            return null;
        }

        public bool IsEnabled(LogLevel logLevel)
        {
            return _dbLoggerProvider.Options.DBOptions.EnabledLogLevels.Contains(logLevel.ToString());
        }

        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception? exception, Func<TState, Exception?, string> formatter)
        {
            if (!IsEnabled(logLevel))
            {
                return;
            }

            if (_dbLoggerProvider.Options.DBOptions.IsDBLogEnabled)
            {
                using (var connection = new SqlConnection(_dbLoggerProvider.Options.DBOptions.ConnectionString))
                {
                    connection.Open();

                    var _params = new DynamicParameters();

                    _params.Add("@logLevel", logLevel.ToString());

                    _params.Add("@EventName", eventId.Name);

                    _params.Add("@Message", formatter(state, exception));

                    _params.Add("@Exception", exception?.ToString());


                    var isSaved = (connection.Query<bool>(_dbLoggerProvider.Options.DBOptions.SPName, _params, commandType: CommandType.StoredProcedure)).FirstOrDefault();

                    connection.Close();
                }
            }
            var path = _dbLoggerProvider.Options.FileOptions.LogFilePath + DateTime.Now.ToString("yyyy-MM-dd");
            DirectoryInfo di = Directory.CreateDirectory(path);
            var fileName = $"{DateTime.Now.ToString("yyyy-MM-dd hhmm")}_{logLevel}.txt";
            string fullFilePath = Path.Combine(path, fileName);
            var n = Environment.NewLine;
            string exc = "";
            if (exception != null) exc = n + exception.GetType() + ": " + exception.Message + n + exception.StackTrace + n;
            File.AppendAllText(fullFilePath, logLevel.ToString() + ": " + DateTime.Now.ToString() + " " + formatter(state, exception) + n + exc);
        }
    }
}
