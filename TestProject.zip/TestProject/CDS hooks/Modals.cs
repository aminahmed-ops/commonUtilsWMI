﻿namespace CDS_hooks
{
    public class Patient
    {
        public string Name { get; set; }
        public int Age{ get; set; }
        // Add other patient attributes such as age, gender, etc.
    }

    public class ClinicalGuideline
    {
        public string Title { get; set; }
        public string Description { get; set; }
        // Add other guideline attributes such as criteria, references, etc.
    }

    public class DecisionSupportResponse
    {
        public string Recommendation { get; set; }
        public string Explanation { get; set; }
        // Add other response attributes such as references, links, etc.
    }
}
