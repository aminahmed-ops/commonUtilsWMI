using Microsoft.AspNetCore.Mvc;

namespace CDS_hooks.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    };

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

        [HttpGet(Name = "GetWeatherForecast")]
        public IEnumerable<WeatherForecast> Get()
        {
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateTime.Now.AddDays(index),
                TemperatureC = Random.Shared.Next(-20, 55),
                Summary = Summaries[Random.Shared.Next(Summaries.Length)]
            })
            .ToArray();
        }

        [HttpPost(Name = "ProcessCDSHooks")]
        public IEnumerable<WeatherForecast> ProcessCDSHooks()
        {
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateTime.Now.AddDays(index),
                TemperatureC = Random.Shared.Next(-20, 55),
                Summary = Summaries[Random.Shared.Next(Summaries.Length)]
            })
            .ToArray();
        }

        [HttpPost]
        public IActionResult GenerateRecommendation([FromBody] Patient patient)
        {
            if (patient == null)
            {
                return BadRequest("Patient data is required.");
            }

            var response = this.GenerateRecommendations(patient);
            return Ok(response);
        }





        public DecisionSupportResponse GenerateRecommendations(Patient patient)
        {
            // Implement decision support logic based on clinical guidelines and patient data
            // Example: Check patient's age and recommend preventive screenings
            if (patient.Age >= 50)
            {
                return new DecisionSupportResponse
                {
                    Recommendation = "Recommend annual mammogram for cancer screening.",
                    Explanation = "Annual mammograms are recommended for women aged 50 and above to detect breast cancer early."
                };
            }
            else
            {
                return new DecisionSupportResponse
                {
                    Recommendation = "No specific recommendation at this time.",
                    Explanation = "No specific preventive screenings recommended based on age alone."
                };
            }
        }





    }
}