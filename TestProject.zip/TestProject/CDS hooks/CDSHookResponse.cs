﻿using Newtonsoft.Json;

namespace CDS_hooks
{
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);
    public class Action
    {
        [JsonProperty("type")]
        public string Type;

        [JsonProperty("description")]
        public string Description;

        [JsonProperty("resource")]
        public Resource Resource;
    }

    public class Card
    {
        [JsonProperty("summary")]
        public string Summary;

        [JsonProperty("detail")]
        public string Detail;

        [JsonProperty("uuid")]
        public string Uuid;

        [JsonProperty("source")]
        public Source Source;

        [JsonProperty("links")]
        public List<Link> Links;

        [JsonProperty("suggestions")]
        public List<Suggestion> Suggestions;
    }

    public class Category
    {
        [JsonProperty("text")]
        public string Text;

        [JsonProperty("coding")]
        public List<Coding> Coding;
    }

    public class Code
    {
        [JsonProperty("text")]
        public string Text;

        [JsonProperty("coding")]
        public List<Coding> Coding;
    }

    public class Coding
    {
        [JsonProperty("code")]
        public string Code;

        [JsonProperty("system")]
        public string System;
    }

    public class Link
    {
        [JsonProperty("label")]
        public string Label;

        [JsonProperty("url")]
        public string Url;

        [JsonProperty("type")]
        public string Type;

        [JsonProperty("appContext")]
        public string AppContext;
    }

    public class Resource
    {
        [JsonProperty("code")]
        public Code Code;

        [JsonProperty("category")]
        public List<Category> Category;

        [JsonProperty("resourceType")]
        public string ResourceType;

        [JsonProperty("subject")]
        public Subject Subject;
    }

    public class Root
    {
        [JsonProperty("cards")]
        public List<Card> Cards;
    }

    public class Source
    {
        [JsonProperty("label")]
        public string Label;

        [JsonProperty("icon")]
        public string Icon;

        [JsonProperty("url")]
        public string Url;
    }

    public class Subject
    {
        [JsonProperty("reference")]
        public string Reference;
    }

    public class Suggestion
    {
        [JsonProperty("label")]
        public string Label;

        [JsonProperty("uuid")]
        public string Uuid;

        [JsonProperty("isRecommended")]
        public bool? IsRecommended;

        [JsonProperty("actions")]
        public List<Action> Actions;
    }


}
