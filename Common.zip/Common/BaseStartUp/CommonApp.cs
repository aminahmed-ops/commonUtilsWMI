﻿using Common.Middlewares;
using Microsoft.AspNetCore.Builder;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.BaseStartUp
{
    public class CommonApp
    {
        private WebApplicationBuilder _builder;
        public CommonApp(WebApplicationBuilder builder)
        {
            _builder = builder;
        }
        public async Task<WebApplication> GetApp(string swaggerApplicationName="")
        {
            var app = _builder.Build();

            app.UseHttpsRedirection();

            app.UseAuthorization();

            app.MapControllers();
            app.UseSwagger();

            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", !string.IsNullOrEmpty(swaggerApplicationName)? swaggerApplicationName:"API");
                c.RoutePrefix = "swagger";
            });
            //app.UseMiddleware<LoggerMiddleware>();

            return app;
        }
    }
}
