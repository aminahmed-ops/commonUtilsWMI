﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;
using System.Reflection;

namespace Common.BaseStartUp
{
    public class CommonBuilder
    {
        private WebApplicationBuilder _builder;
        public CommonBuilder(string[] args)
        {
            _builder = WebApplication.CreateBuilder(args); 
        }
        public async Task<WebApplicationBuilder> GetBuilder(string projectName,string swaggerDescription="")
        {
            _builder.Services.AddControllers();

            _builder.Services.AddEndpointsApiExplorer();

            #region Swagger Configuration
            _builder.Services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Version = "v1",
                    Title = $"{projectName.ToUpper()}",
                    Description = !string.IsNullOrEmpty(swaggerDescription)? swaggerDescription : "This documentation contains list of endpoints along with detailed payload and response.",
                    TermsOfService = new Uri("https://www.wisemaninnovations.com/terms"),
                    Contact = new OpenApiContact
                    {
                        Name = "Wiseman Innovations LLC",
                        Email = "info@wisemani.com",
                        Url = new Uri("https://www.wisemaninnovations.com"),
                    },
                    License = new OpenApiLicense
                    {
                        Name = "Use under LICX",
                        Url = new Uri("https://www.wisemaninnovations.com/license"),
                    },
                });

                var xmlFilename = $"{projectName}.xml";
                c.IncludeXmlComments(Path.Combine(AppContext.BaseDirectory, xmlFilename));
                c.CustomSchemaIds(type => type.ToString());
            });
            #endregion

            _builder.Services.AddSwaggerGen();
            
            return _builder;
        }
    }
}
