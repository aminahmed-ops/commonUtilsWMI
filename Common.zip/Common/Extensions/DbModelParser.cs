﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Extensions
{
    public static class DbModelParser
    {

        public static string? GetPatientName(List<Hl7.Fhir.Model.HumanName> humanName)
        {
            if (humanName == null) return null;
            string? familyName = null, givenName = null;
            foreach (var names in humanName.Where(s => s.Use?.ToString().ToLower() == "official"))
            {
                familyName = names?.Family.ToString();
                if (names?.Given.Count() > 0)
                {
                    givenName = ExtensionMethods.GiveName(names?.Given.ToArray() ?? Array.Empty<string>());
                    break;
                }
            }
            return $"{givenName} {familyName}";
        }
    }
}
