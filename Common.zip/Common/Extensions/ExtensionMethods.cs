﻿using Hl7.Fhir.Model;
using Hl7.Fhir.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Dynamic;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Common.Extensions
{
    public static class ExtensionMethods
    {
        #region Enum_Description

        /// <summary>
        /// Gets the enum description.
        /// </summary>
        /// <typeparam name="TEnum">The type of the t enum.</typeparam>
        /// <param name="value">The value.</param>
        /// <returns>System.String.</returns>
        public static string GetEnumDescription<TEnum>(TEnum value)
        {
            var field = value.GetType().GetField(value.ToString());
            var attributes = (DescriptionAttribute[])field.GetCustomAttributes(typeof(DescriptionAttribute), false);
            return attributes.Length > 0 ? attributes[0].Description : value.ToString();
        }

        /// <summary>
        /// Gets the enum descriptions.
        /// </summary>
        /// <typeparam name="TEnum">The type of the t enum.</typeparam>
        /// <param name="value">The value.</param>
        /// <returns>System.String.</returns>
        public static string GetEnumDescriptions<TEnum>(this int value)
        {
            return GetEnumDescription((Enum)(object)((TEnum)(object)value));  // ugly, but works
        }
        /// <summary>
        /// GetDescription
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="enumerationValue"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentException"></exception>
        public static string GetDescription<T>(this T enumerationValue) where T : struct
        {
            Type type = enumerationValue.GetType();
            if (!type.IsEnum)
            {
                throw new ArgumentException("EnumerationValue must be of Enum type", "enumerationValue");
            }

            //Tries to find a DescriptionAttribute for a potential friendly name
            //for the enum
            MemberInfo[] memberInfo = type.GetMember(enumerationValue.ToString());
            if (memberInfo != null && memberInfo.Length > 0)
            {
                object[] attrs = memberInfo[0].GetCustomAttributes(typeof(DescriptionAttribute), false);

                if (attrs != null && attrs.Length > 0)
                {
                    //Pull out the description value
                    return ((DescriptionAttribute)attrs[0]).Description;
                }
            }
            //If we have no description attribute, just return the ToString of the enum
            return enumerationValue.ToString();
        }
        #endregion Enum_Description
        /// <summary>
		///   Convert parameters into a URL query string.
		/// </summary>
		/// <param name="parameters">The parameters to encode</param>
		/// <returns>The URL query string</returns>
		public static string UrlEncode(Dictionary<string, string> parameters)
        {
            // Encode each key and value, join with "=", then join pairs with "&"
            return string.Join("&", parameters.Select(
              kvp => WebUtility.UrlEncode(kvp.Key) + "=" + WebUtility.UrlEncode(kvp.Value)
            ).ToList());
        }
        

        /// <summary>
        ///   Join arguments into a valid URL.
        /// </summary>
        /// <param name="args">Any number of strings to join</param>
        /// <returns>The resulting URL</returns>
        public static string PathJoin(params string[] args)
        {
            // Trim slashes, filter out empties, join by slashes
            return string.Join("/", args
                               .Select(arg => arg.Trim(new char[] { '/' }))
                               .Where(arg => !String.IsNullOrEmpty(arg))
            );
        }

        public static string? GiveName(params string[] args)
        {
            return String.Join(" ", args.Where(s => !String.IsNullOrEmpty(s)));
        }

        public static DateTime? StringToDatetime(string? date)
        {
            if (date == null) return null;
            DateTime dateTime;
            var isParsed = DateTime.TryParse(date, out dateTime);
            return isParsed ? dateTime : null;
        }

        public static string GetAddress(Hl7.Fhir.Model.Address address)
        {
            return $"{address.Country} {address.City} {address.Use} {address.State} {address.PostalCode} {address.Line.FirstOrDefault()}";
        }
        public static object ConvertJsonToModal(this object Types,string json)
        {
            return new object();
        }
        public static dynamic ToDynamic(this JToken token)
        {
            if (token == null)
                return null;
            else if (token is JObject)
                return token.ToObject<ExpandoObject>();
            else if (token is JArray)
                return token.ToObject<List<ExpandoObject>>().Cast<dynamic>().ToList();
            else if (token is JValue)
                return ((JValue)token).Value;
            else
                // JConstructor, JRaw
                throw new JsonSerializationException(string.Format("Token type not implemented: {0}", token));
        }
        public static Dictionary<string,string> ToKeyValueDictionary(this object obj)
        {
            if (obj == null)
            {
                return new Dictionary<string, string>();
            }
            var dataString = JsonConvert.SerializeObject(obj);

            var data = JsonConvert.DeserializeObject<Dictionary<string, string>>(dataString);

            return data;
        }
    }
}
