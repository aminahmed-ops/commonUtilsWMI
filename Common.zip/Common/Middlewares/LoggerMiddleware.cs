﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System.Data.SqlClient;
using System.Data;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Http;
using Models.Common;
using System.ComponentModel.DataAnnotations;
using System.Net;

namespace Common.Middlewares
{
    public class LoggerMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly AppSettings _appSettings;
        public LoggerMiddleware(RequestDelegate next, IOptions<AppSettings> options)
        {
            _next = next;
            _appSettings = options.Value;
        }
        public async Task InvokeAsync(HttpContext context)
        {
                var requestUrl = context.Request.Scheme + "://" + context.Request.Host + context.Request.PathBase + context.Request.Path.ToString() + context.Request.QueryString.Value;
                var requestMethod = context.Request.Method;
                var requestHeaders = JsonConvert.SerializeObject(context.Request.Headers);
                var requestBody = await FormatRequest(context.Request);

                var originalBodyStream = context.Response.Body;
         
                // Format incoming request as a string


                using (var responseBody = new MemoryStream())
                {
                    context.Response.Body = responseBody;

                    await _next(context);

                    // Format outgoing response as a string
                    var responseStatusCode = context.Response.StatusCode;
                    var responseHeaders = JsonConvert.SerializeObject(context.Response.Headers);
                    var responseBodyString = await FormatResponse(context.Response);

                    // Write the log to the database
                    WriteLogToDatabase(requestUrl, requestMethod, requestHeaders, requestBody,
                        responseStatusCode, responseHeaders, responseBodyString);
                    string log = JsonConvert.SerializeObject(new
                    {
                        requestUrl,
                        requestMethod,
                        requestHeaders,
                        requestBody,
                        responseStatusCode,
                        responseHeaders,
                        responseBodyString
                    });


                    await responseBody.CopyToAsync(originalBodyStream);
                }

        }

        private void WriteLogToDatabase(string requestUrl, string requestMethod, string requestHeaders, string requestBody, int? responseStatusCode, string responseHeaders, string responseBody)
        {
            // Create a new SqlConnection instance using the connection string
            using (var connection = new SqlConnection(_appSettings.ConnectionStrings["LogsDb"]))
            {
                // Open the database connection
                connection.Open();
                var query = "usp_Fhir_Api_Logs";
                // Create a new SqlCommand instance using the connection and a parameterized SQL INSERT command
                using (var command = new SqlCommand(query
                    , connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    // Set the command parameters using the log values
                    command.Parameters.AddWithValue("@RequestUrl", requestUrl);
                    command.Parameters.AddWithValue("@RequestMethod", requestMethod);
                    command.Parameters.AddWithValue("@RequestHeaders", requestHeaders);
                    command.Parameters.AddWithValue("@RequestBody", requestBody);
                    command.Parameters.AddWithValue("@ResponseStatusCode", responseStatusCode);
                    command.Parameters.AddWithValue("@ResponseHeaders", responseHeaders);
                    command.Parameters.AddWithValue("@ResponseBody", responseBody);
                    command.Parameters.AddWithValue("@Timestamp", DateTime.UtcNow);

                    // Execute the command
                    command.ExecuteNonQuery();
                }

            }
        }
        private static async Task<string> FormatRequest(HttpRequest request)
        {
            request.EnableBuffering();

            var body = await new StreamReader(request.Body).ReadToEndAsync();

            request.Body.Position = 0;

            return $"{body}";
        }

        private static async Task<string> FormatResponse(HttpResponse response)
        {
            response.Body.Seek(0, SeekOrigin.Begin);

            var body = await new StreamReader(response.Body).ReadToEndAsync();

            response.Body.Seek(0, SeekOrigin.Begin);

            return $"{body}";
        }
    }
}
